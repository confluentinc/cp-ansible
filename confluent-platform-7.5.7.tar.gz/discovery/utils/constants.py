from discovery.utils.utils import InputContext

DEFAULT_KEY = "Default"
DEFAULT_GROUP_NAME = 'all'
